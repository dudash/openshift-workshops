#!/bin/bash
for id in $(docker ps -aq); do docker rm $id; done
