#!/bin/bash
for id in $(docker images -q); do docker rmi $id; done
