#!/bin/bash
for id in $(docker ps -q); do docker stop $id; done
